package com.project.cinema.ticket;

import java.util.Scanner;

public class MovieSelect {
}
